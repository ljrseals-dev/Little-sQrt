# Little sQrt Meter (VST3)

Real-time loudness meter plug-in based on the Little sQrt DSP: BS.1770-4 K-weighting,
momentary (400 ms), short-term (3 s), gated integrated LUFS, and 4x true peak.
Audio passes through unchanged. Readouts appear as read-only parameters in your DAW's
generic plug-in UI (use a "Reset" parameter to clear integrated / true-peak).

Build on Windows: run `build_vst3.bat` (add `Release install` as admin to install).
