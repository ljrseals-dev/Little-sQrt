@echo off
setlocal EnableDelayedExpansion
REM ==========================================================================
REM  build_vst3.bat  -  Little sQrt Meter (real-time BS.1770-4 / EBU R128)
REM
REM  Requirements: Visual Studio 2022 (Desktop development with C++),
REM                CMake 3.25+, Git (only to fetch the Steinberg VST3 SDK).
REM
REM    build_vst3.bat                    Release build
REM    build_vst3.bat Debug              Debug build
REM    build_vst3.bat Release install    Build + copy to the system VST3 folder
REM                                      (run from an Administrator prompt)
REM ==========================================================================

set "NAME=LittleSqrtMeter"
set "VS_GENERATOR=Visual Studio 17 2022"
set "ROOT=%~dp0"
set "VST3_SDK_ROOT=%ROOT%vst3sdk"
set "BUILD_DIR=%ROOT%build"

set "CONFIG=%~1"
if "%CONFIG%"=="" set "CONFIG=Release"

where cmake >nul 2>&1 || (echo [ERROR] CMake not found on PATH. & goto :fail)

if not exist "%VST3_SDK_ROOT%\CMakeLists.txt" (
    echo === Fetching Steinberg VST3 SDK ===
    where git >nul 2>&1 || (echo [ERROR] Git not found on PATH. & goto :fail)
    git clone --recursive https://github.com/steinbergmedia/vst3sdk.git "%VST3_SDK_ROOT%" || goto :fail
)

echo === Configuring ===
cmake -S "%ROOT%." -B "%BUILD_DIR%" -G "%VS_GENERATOR%" -A x64 -DVST3_SDK_ROOT="%VST3_SDK_ROOT%" || goto :fail

echo === Building %CONFIG% ===
cmake --build "%BUILD_DIR%" --config %CONFIG% --target %NAME% --parallel || goto :fail

set "OUT=%BUILD_DIR%\VST3\%CONFIG%\%NAME%.vst3"
if not exist "%OUT%" (
    echo [WARN] Expected "%OUT%" - searching:
    dir /s /b "%BUILD_DIR%\*.vst3"
    goto :done
)
echo Built: %OUT%

if /i "%~2"=="install" (
    set "DEST=%CommonProgramFiles%\VST3"
    net session >nul 2>&1 || (echo [ERROR] Run as Administrator to install. & goto :fail)
    if not exist "!DEST!" mkdir "!DEST!"
    xcopy "%OUT%" "!DEST!\%NAME%.vst3\" /E /I /Y >nul || goto :fail
    echo Installed to !DEST!  - rescan plug-ins in your DAW.
)

:done
endlocal
exit /b 0

:fail
echo === Build FAILED ===
endlocal
exit /b 1
