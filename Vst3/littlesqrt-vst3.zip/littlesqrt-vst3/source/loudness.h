// Little sQrt real-time loudness engine (ITU-R BS.1770-4 / EBU R128).
// Header-only, no SDK dependencies, no allocation after prepare().
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <vector>

namespace LittleSqrt {

constexpr double kFloorLUFS = -70.0;

struct Biquad
{
	double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
	double z1 = 0, z2 = 0;
	inline double process (double x)
	{
		const double y = b0 * x + z1;
		z1 = b1 * x - a1 * y + z2;
		z2 = b2 * x - a2 * y;
		return y;
	}
	void reset () { z1 = z2 = 0; }
};

// K-weighting = high-shelf (pre-filter) followed by RLB high-pass.
// Coefficients derived for any sample rate (same formulation as libebur128).
inline void makeKWeighting (double fs, Biquad& shelf, Biquad& hp)
{
	const double pi = 3.14159265358979323846;
	{
		const double f0 = 1681.974450955533, G = 3.999843853973347, Q = 0.7071752369554196;
		const double K = std::tan (pi * f0 / fs);
		const double Vh = std::pow (10.0, G / 20.0);
		const double Vb = std::pow (Vh, 0.4996667741545416);
		const double a0 = 1.0 + K / Q + K * K;
		shelf.b0 = (Vh + Vb * K / Q + K * K) / a0;
		shelf.b1 = 2.0 * (K * K - Vh) / a0;
		shelf.b2 = (Vh - Vb * K / Q + K * K) / a0;
		shelf.a1 = 2.0 * (K * K - 1.0) / a0;
		shelf.a2 = (1.0 - K / Q + K * K) / a0;
	}
	{
		const double f0 = 38.13547087602444, Q = 0.5003270373238773;
		const double K = std::tan (pi * f0 / fs);
		const double a0 = 1.0 + K / Q + K * K;
		hp.b0 = 1.0;
		hp.b1 = -2.0;
		hp.b2 = 1.0;
		hp.a1 = 2.0 * (K * K - 1.0) / a0;
		hp.a2 = (1.0 - K / Q + K * K) / a0;
	}
}

inline double energyToLUFS (double e)
{
	return e > 1e-12 ? -0.691 + 10.0 * std::log10 (e) : -200.0;
}

// 4x oversampled true-peak detector (windowed-sinc polyphase FIR, 48 taps).
class TruePeak
{
public:
	TruePeak ()
	{
		const double pi = 3.14159265358979323846;
		for (int n = 0; n < kTaps; ++n)
		{
			const double x = (n - (kTaps - 1) / 2.0) / kOver;
			const double s = std::fabs (x) < 1e-12 ? 1.0 : std::sin (pi * x) / (pi * x);
			const double w = 0.5 - 0.5 * std::cos (2.0 * pi * (n + 0.5) / kTaps); // Hann
			h[n] = s * w; // sum over taps ~= kOver, so each phase has ~unity gain
		}
		reset ();
	}
	void reset ()
	{
		hist.fill (0.0);
		pos = 0;
	}
	// returns max |interpolated sample| for this input sample
	inline double process (double x)
	{
		pos = (pos + 1) % kPer;
		hist[pos] = x;
		double peak = std::fabs (x);
		for (int p = 0; p < kOver; ++p)
		{
			double acc = 0.0;
			for (int k = 0; k < kPer; ++k)
				acc += h[k * kOver + p] * hist[(pos - k + kPer) % kPer];
			peak = std::max (peak, std::fabs (acc));
		}
		return peak;
	}

private:
	static constexpr int kOver = 4;
	static constexpr int kPer = 12;
	static constexpr int kTaps = kOver * kPer;
	std::array<double, kTaps> h {};
	std::array<double, kPer> hist {};
	int pos = 0;
};

class Meter
{
public:
	static constexpr int kMaxCh = 2;

	void prepare (double sampleRate, int numChannels)
	{
		fs = sampleRate;
		nch = std::min (std::max (numChannels, 1), kMaxCh);
		hop = static_cast<int> (std::lround (fs * 0.1)); // 100 ms hop (75% overlap for 400 ms)
		for (int c = 0; c < kMaxCh; ++c)
			makeKWeighting (fs, shelf[c], hpf[c]);
		reset ();
	}

	void reset ()
	{
		for (int c = 0; c < kMaxCh; ++c)
		{
			shelf[c].reset ();
			hpf[c].reset ();
			tp[c].reset ();
		}
		hopSum = 0.0;
		hopCount = 0;
		ring.fill (0.0);
		ringPos = 0;
		blocksSeen = 0;
		histCount.fill (0);
		histEnergy.fill (0.0);
		momentary = shortTerm = integrated = kFloorLUFS;
		truePeakMax = 0.0;
	}

	// planar float input
	void process (const float* const* in, int numSamples)
	{
		for (int i = 0; i < numSamples; ++i)
		{
			double e = 0.0;
			for (int c = 0; c < nch; ++c)
			{
				const double x = in[c][i];
				truePeakMax = std::max (truePeakMax, tp[c].process (x));
				const double y = hpf[c].process (shelf[c].process (x));
				e += y * y; // channel weight 1.0 for L/R
			}
			hopSum += e;
			if (++hopCount >= hop)
				finishHop ();
		}
	}

	double getMomentary () const { return momentary; }
	double getShortTerm () const { return shortTerm; }
	double getIntegrated () const { return integrated; }
	double getTruePeakDb () const
	{
		return truePeakMax > 1e-7 ? 20.0 * std::log10 (truePeakMax) : -200.0;
	}

private:
	static constexpr int kRing = 30; // 3 s of 100 ms hops
	static constexpr int kBins = 1000; // 0.1 LU bins from -70 LUFS

	double meanOfLast (int n) const
	{
		double s = 0.0;
		for (int i = 0; i < n; ++i)
			s += ring[(ringPos - 1 - i + kRing * 2) % kRing];
		return s / n;
	}

	void finishHop ()
	{
		ring[ringPos] = hopSum / hopCount;
		ringPos = (ringPos + 1) % kRing;
		hopSum = 0.0;
		hopCount = 0;
		if (blocksSeen < kRing)
			++blocksSeen;

		if (blocksSeen >= 4)
		{
			const double e = meanOfLast (4);
			momentary = std::max (energyToLUFS (e), kFloorLUFS);
			const double l = energyToLUFS (e);
			if (l > kFloorLUFS) // absolute gate
			{
				int bin = static_cast<int> ((l - kFloorLUFS) * 10.0);
				bin = std::min (std::max (bin, 0), kBins - 1);
				++histCount[bin];
				histEnergy[bin] += e;
			}
			updateIntegrated ();
		}
		if (blocksSeen >= kRing)
			shortTerm = std::max (energyToLUFS (meanOfLast (kRing)), kFloorLUFS);
	}

	void updateIntegrated ()
	{
		double sum = 0.0;
		long long cnt = 0;
		for (int b = 0; b < kBins; ++b)
		{
			sum += histEnergy[b];
			cnt += histCount[b];
		}
		if (cnt == 0)
		{
			integrated = kFloorLUFS;
			return;
		}
		const double relGate = energyToLUFS (sum / cnt) - 10.0;
		int start = static_cast<int> (std::floor ((relGate - kFloorLUFS) * 10.0));
		start = std::min (std::max (start, 0), kBins - 1);
		sum = 0.0;
		cnt = 0;
		for (int b = start; b < kBins; ++b)
		{
			sum += histEnergy[b];
			cnt += histCount[b];
		}
		integrated = cnt ? std::max (energyToLUFS (sum / cnt), kFloorLUFS) : kFloorLUFS;
	}

	double fs = 48000.0;
	int nch = 2;
	int hop = 4800;
	std::array<Biquad, kMaxCh> shelf, hpf;
	std::array<TruePeak, kMaxCh> tp;
	double hopSum = 0.0;
	int hopCount = 0;
	std::array<double, kRing> ring {};
	int ringPos = 0;
	int blocksSeen = 0;
	std::array<long long, kBins> histCount {};
	std::array<double, kBins> histEnergy {};
	double momentary = kFloorLUFS, shortTerm = kFloorLUFS, integrated = kFloorLUFS;
	double truePeakMax = 0.0;
};

} // namespace LittleSqrt
