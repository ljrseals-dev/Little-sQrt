#include "controller.h"
#include "ids.h"
#include "processor.h"
#include "version.h"
#include "public.sdk/source/main/pluginfactory.h"

using namespace Steinberg;
using namespace Steinberg::Vst;

BEGIN_FACTORY_DEF (stringCompanyName, stringCompanyWeb, stringCompanyEmail)

	DEF_CLASS2 (INLINE_UID_FROM_FUID (LittleSqrt::ProcessorUID), PClassInfo::kManyInstances,
	            kVstAudioEffectClass, stringPluginName, Vst::kDistributable,
	            PlugType::kFxAnalyzer, FULL_VERSION_STR, kVstVersionString,
	            LittleSqrt::Processor::createInstance)

	DEF_CLASS2 (INLINE_UID_FROM_FUID (LittleSqrt::ControllerUID), PClassInfo::kManyInstances,
	            kVstComponentControllerClass, stringPluginName "Controller", 0, "",
	            FULL_VERSION_STR, kVstVersionString, LittleSqrt::Controller::createInstance)

END_FACTORY
