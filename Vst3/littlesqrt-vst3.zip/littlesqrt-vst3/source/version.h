#pragma once
#define stringCompanyName "ljrseals-dev"
#define stringCompanyWeb "https://github.com/ljrseals-dev"
#define stringCompanyEmail "mailto:none@example.com"
#define FULL_VERSION_STR "2.0.1"
#define stringPluginName "Little sQrt Meter"
