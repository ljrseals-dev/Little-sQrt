#pragma once
#include "pluginterfaces/base/funknown.h"
#include "pluginterfaces/vst/vsttypes.h"

namespace LittleSqrt {

// Generated unique class IDs - do not reuse for other plug-ins.
static const Steinberg::FUID ProcessorUID (0x4C53514D, 0x45544552, 0x50524F43, 0x00000201);
static const Steinberg::FUID ControllerUID (0x4C53514D, 0x45544552, 0x434F4E54, 0x00000201);

enum ParamIds : Steinberg::Vst::ParamID
{
	kMomentaryId = 100,
	kShortTermId = 101,
	kIntegratedId = 102,
	kTruePeakId = 103,
	kResetId = 104
};

// Read-out parameters use a fixed plain range so processor and controller agree.
constexpr double kMeterMin = -70.0;
constexpr double kMeterMax = 10.0;
inline double plainToNorm (double v)
{
	const double n = (v - kMeterMin) / (kMeterMax - kMeterMin);
	return n < 0.0 ? 0.0 : (n > 1.0 ? 1.0 : n);
}

} // namespace LittleSqrt
