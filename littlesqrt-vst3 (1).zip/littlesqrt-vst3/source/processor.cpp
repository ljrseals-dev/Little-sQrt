#include "processor.h"
#include "ids.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include "pluginterfaces/vst/vstspeaker.h"
#include <cstring>

using namespace Steinberg;
using namespace Steinberg::Vst;

namespace LittleSqrt {

Processor::Processor ()
{
	setControllerClass (ControllerUID);
}

tresult PLUGIN_API Processor::initialize (FUnknown* context)
{
	tresult r = AudioEffect::initialize (context);
	if (r != kResultOk)
		return r;
	addAudioInput (STR16 ("Stereo In"), SpeakerArr::kStereo);
	addAudioOutput (STR16 ("Stereo Out"), SpeakerArr::kStereo);
	return kResultOk;
}

tresult PLUGIN_API Processor::setBusArrangements (SpeakerArrangement* inputs, int32 numIns,
                                                  SpeakerArrangement* outputs, int32 numOuts)
{
	if (numIns == 1 && numOuts == 1 && inputs[0] == outputs[0] &&
	    (inputs[0] == SpeakerArr::kStereo || inputs[0] == SpeakerArr::kMono))
		return AudioEffect::setBusArrangements (inputs, numIns, outputs, numOuts);
	return kResultFalse;
}

tresult PLUGIN_API Processor::canProcessSampleSize (int32 symbolicSampleSize)
{
	return symbolicSampleSize == kSample32 ? kResultTrue : kResultFalse;
}

tresult PLUGIN_API Processor::setupProcessing (ProcessSetup& setup)
{
	sampleRate = setup.sampleRate;
	int ch = 2;
	if (!audioInputs.empty ())
		ch = SpeakerArr::getChannelCount (static_cast<AudioBus*> (audioInputs[0].get ())->getArrangement ());
	meter.prepare (sampleRate, ch);
	return AudioEffect::setupProcessing (setup);
}

tresult PLUGIN_API Processor::setActive (TBool state)
{
	if (state)
		meter.reset ();
	return AudioEffect::setActive (state);
}

tresult PLUGIN_API Processor::process (ProcessData& data)
{
	// --- parameter input (Reset button) ---
	if (data.inputParameterChanges)
	{
		const int32 n = data.inputParameterChanges->getParameterCount ();
		for (int32 i = 0; i < n; ++i)
		{
			IParamValueQueue* q = data.inputParameterChanges->getParameterData (i);
			if (q && q->getParameterId () == kResetId)
			{
				const int32 pts = q->getPointCount ();
				if (pts > 0)
				{
					int32 off;
					ParamValue v;
					if (q->getPoint (pts - 1, off, v) == kResultTrue)
					{
						const bool on = v > 0.5;
						if (on && !resetHeld)
							meter.reset ();
						resetHeld = on;
					}
				}
			}
		}
	}

	if (data.numInputs == 0 || data.numOutputs == 0 || data.numSamples == 0)
		return kResultOk;

	AudioBusBuffers& in = data.inputs[0];
	AudioBusBuffers& out = data.outputs[0];
	const int32 numCh = std::min (in.numChannels, out.numChannels);

	// --- pass-through audio ---
	for (int32 c = 0; c < numCh; ++c)
		if (out.channelBuffers32[c] != in.channelBuffers32[c])
			std::memcpy (out.channelBuffers32[c], in.channelBuffers32[c],
			             sizeof (float) * static_cast<size_t> (data.numSamples));
	out.silenceFlags = in.silenceFlags;

	// --- measure (mono input is fed to a 1-channel meter pass) ---
	if (!(in.silenceFlags & 1) || numCh > 1)
	{
		const float* chans[Meter::kMaxCh] = {in.channelBuffers32[0],
		                                     numCh > 1 ? in.channelBuffers32[1] : in.channelBuffers32[0]};
		meter.process (chans, data.numSamples);
	}
	else
	{
		// silent block: feed zeros so time keeps advancing
		static thread_local float zeros[4096] = {};
		int32 left = data.numSamples;
		while (left > 0)
		{
			const int32 n = std::min<int32> (left, 4096);
			const float* z[Meter::kMaxCh] = {zeros, zeros};
			meter.process (z, n);
			left -= n;
		}
	}

	// --- report read-outs to controller ---
	if (data.outputParameterChanges)
	{
		auto put = [&] (ParamID id, double normalized) {
			int32 idx = 0;
			if (IParamValueQueue* q = data.outputParameterChanges->addParameterData (id, idx))
			{
				int32 pidx = 0;
				q->addPoint (0, normalized, pidx);
			}
		};
		put (kMomentaryId, plainToNorm (meter.getMomentary ()));
		put (kShortTermId, plainToNorm (meter.getShortTerm ()));
		put (kIntegratedId, plainToNorm (meter.getIntegrated ()));
		put (kTruePeakId, plainToNorm (meter.getTruePeakDb ()));
		put (kLRAId, lraToNorm (meter.getLRA ()));
	}
	return kResultOk;
}

tresult PLUGIN_API Processor::setState (IBStream*) { return kResultOk; }
tresult PLUGIN_API Processor::getState (IBStream*) { return kResultOk; }

} // namespace LittleSqrt
