#include "controller.h"
#include "ids.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include "base/source/fstring.h"
#include "vstgui/plugin-bindings/vst3editor.h"

using namespace Steinberg;
using namespace Steinberg::Vst;

namespace LittleSqrt {

tresult PLUGIN_API Controller::initialize (FUnknown* context)
{
	tresult r = EditController::initialize (context);
	if (r != kResultOk)
		return r;

	auto addMeter = [&] (const TChar* title, const TChar* units, ParamID id) {
		auto* p = new RangeParameter (title, id, units, kMeterMin, kMeterMax, kMeterMin, 0,
		                              ParameterInfo::kIsReadOnly);
		p->setPrecision (1);
		parameters.addParameter (p);
	};
	addMeter (STR16 ("Momentary"), STR16 ("LUFS"), kMomentaryId);
	addMeter (STR16 ("Short-Term"), STR16 ("LUFS"), kShortTermId);
	addMeter (STR16 ("Integrated"), STR16 ("LUFS"), kIntegratedId);
	addMeter (STR16 ("True Peak"), STR16 ("dBTP"), kTruePeakId);

	{
		auto* p = new RangeParameter (STR16 ("Loudness Range"), kLRAId, STR16 ("LU"), 0.0, kLraMax,
		                              0.0, 0, ParameterInfo::kIsReadOnly);
		p->setPrecision (1);
		parameters.addParameter (p);
	}

	parameters.addParameter (STR16 ("Reset"), nullptr, 1, 0, ParameterInfo::kCanAutomate,
	                         kResetId);
	return kResultOk;
}

IPlugView* PLUGIN_API Controller::createView (FIDString name)
{
	if (name && ConstString (name) == ViewType::kEditor)
		return new VSTGUI::VST3Editor (this, "view", "littlesqrt.uidesc");
	return nullptr;
}

} // namespace LittleSqrt
