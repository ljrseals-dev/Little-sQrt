# Little sQrt Meter (VST3)

Real-time loudness meter plug-in based on the Little sQrt DSP. Audio passes through unchanged.

Measurements (all computed in real time, no allocation on the audio thread):
- Momentary (400 ms), Short-Term (3 s), gated Integrated LUFS  (ITU-R BS.1770-4)
- Loudness Range, LRA (EBU Tech 3342: -70 LUFS absolute gate, -20 LU relative gate, 10th-95th percentile)
- True Peak, 4x oversampled (dBTP)

UI: a VSTGUI meter window (resource/littlesqrt.uidesc) with bars + numeric readouts and a
Reset button. Hosts that don't show custom editors still expose every readout as a
read-only parameter, plus a "Reset" parameter.

Build on Windows: run `build_vst3.bat`  (`build_vst3.bat Release install` as Administrator to install).
Needs Visual Studio 2022 (C++ workload), CMake 3.25+, Git.

Verification status: compiled and passed the Steinberg SDK validator (47/47) on Linux.
Engine unit tests: 997 Hz, -20 dBFS stereo -> -20.00 LUFS / -20.00 dBTP; steady tone LRA 0.00 LU;
-40/-20 dBFS step LRA 20.00 LU; intersample-peak test -0.06 dBTP.
The Windows .bat and the editor window have not been run on a real Windows host/DAW yet.
Not an independently certified meter - check against the official EBU test files before delivery work.
